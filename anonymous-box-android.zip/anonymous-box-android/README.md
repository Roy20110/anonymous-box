# 问答社区 APP 打包说明

这是一个基于 WebView 的 Android APP，把网页版问答社区包装成原生 APP。

## 📱 功能特性
- 完整的网页版功能（登录注册、提问、回答、个人中心、捐赠）
- 支持返回键（按返回键回到上一页，再按退出）
- 支持文件上传、拍照上传
- 支持视频/音频播放
- 本地缓存，加载更快
- 沉浸式状态栏，APP图标和名称

## 🔧 打包方法（两种方式，选一种）

### 方法一：用 Android Studio 打包（推荐，最稳定）

#### 准备工作
1. 下载安装 Android Studio：https://developer.android.com/studio
2. 安装时勾选 Android SDK，等待安装完成

#### 打包步骤
1. 打开 Android Studio
2. 选择「Open an existing project」，选择这个 `qa-app-android` 文件夹
3. 等待 Gradle 同步完成（第一次会比较慢，需要下载依赖）
4. 修改网页地址（重要！）：
   - 打开 `app/src/main/java/com/qa/app/MainActivity.java`
   - 找到第 35 行：`private static final String APP_URL = "https://roy20110.github.io/qa-app/";`
   - 改成你实际部署的网页地址
5. 生成 APK：
   - 点击顶部菜单「Build」→「Build Bundle(s) / APK(s)」→「Build APK(s)」
   - 等待编译完成
   - 编译成功后会弹出提示，点击「locate」就能找到 APK 文件
   - APK 位置：`app/build/outputs/apk/debug/app-debug.apk`

#### 生成正式版（发布用）
1. 点击「Build」→「Generate Signed Bundle / APK」
2. 选择「APK」，点击下一步
3. 点击「Create new...」创建签名密钥
   - Key store path：选择保存位置，设置文件名
   - Password：设置密钥密码（记住！）
   - Alias：密钥别名，随便填
   - 其他信息随便填
4. 选择「release」，勾选「V1」和「V2」，点击完成
5. 正式版 APK 位置：`app/release/app-release.apk`

---

### 方法二：用在线工具打包（不用装软件，更快）

推荐网站：
1. **HBuilderX 云打包**：https://www.dcloud.io/hbuilderx.html
   - 下载 HBuilderX，新建「5+App」项目
   - 把网页文件放进去，配置启动地址
   - 点击「发行」→「原生App-云打包」
   - 选择 Android，使用公共测试证书，点击打包
   - 等待几分钟，就能下载 APK

2. **在线WebView打包工具**：百度搜「网页转APP在线生成」，有很多免费工具
   - 输入你的网页地址
   - 设置APP名称、图标
   - 点击生成，下载APK

---

## 🎨 自定义修改

### 修改APP名称
打开 `app/src/main/res/values/strings.xml`，修改 `app_name` 的值

### 修改APP图标
1. 准备一张 512x512 的 PNG 图标
2. 用 Android Studio 的 Image Asset 工具生成各尺寸图标：
   - 右键 `res` 文件夹 →「New」→「Image Asset」
   - 选择「Launcher Icons」，选择你的图标
   - 点击完成，自动生成各尺寸图标

### 修改APP主题颜色
打开 `app/src/main/res/values/colors.xml`，修改颜色值

### 修改网页地址
打开 `app/src/main/java/com/qa/app/MainActivity.java`，修改第 35 行的 `APP_URL`

---

## 📦 发布到应用商店

生成正式版 APK 后，可以发布到：
- 应用宝
- 小米应用商店
- 华为应用市场
- OPPO/vivo 应用商店
- 百度手机助手
- 直接放 GitHub 下载（最简单，不用审核）

---

## ⚠️ 注意事项

1. **必须先部署网页版**：APP 只是个壳，实际内容是网页，必须先把网页部署到服务器/GitHub Pages
2. **网页地址要正确**：打包前一定要修改 `APP_URL` 为你实际的网页地址
3. **签名密钥要保存好**：正式版签名密钥丢失后，就无法更新APP了，一定要备份
4. **权限说明**：APP 需要网络、相机、存储权限，用于正常使用和文件上传

---

## 🆘 常见问题

**Q：编译报错怎么办？**
A：一般是 Gradle 同步问题，点击「File」→「Sync Project with Gradle Files」重新同步

**Q：APP打开白屏怎么办？**
A：检查网页地址是否正确，手机是否能正常访问那个网页

**Q：能上架应用商店吗？**
A：可以，但是纯 WebView APP 有些应用商店审核比较严，建议加一些原生功能，或者用企业资质上架

**Q：能加微信/QQ登录吗？**
A：可以，需要在微信开放平台/QQ互联注册开发者，创建应用，获取 AppID，然后在 Android 项目里集成对应的 SDK
